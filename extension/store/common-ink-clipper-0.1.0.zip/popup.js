"use strict";
(() => {
  // extension/src/clip/folders.ts
  function filterFolders(list, query) {
    const editable = list.folders.filter((folder) => folder.access === "edit");
    const needle = fold(query.trim());
    if (!needle) {
      const unsorted = editable.filter((folder) => folder.id === list.unsortedId);
      const rest = editable.filter((folder) => folder.id !== list.unsortedId).sort((a, b) => a.path.localeCompare(b.path, void 0, { sensitivity: "base" }));
      return [...unsorted, ...rest];
    }
    return editable.filter((folder) => fold(folder.path).includes(needle));
  }
  function fold(value) {
    return value.normalize("NFKD").replace(new RegExp("\\p{M}", "gu"), "").toLowerCase();
  }

  // src/core/uploadRefs.ts
  var UPLOAD_EMBEDS = ["image", "video", "audio", "file"];
  var REF = new RegExp(`(?<!:)::(${UPLOAD_EMBEDS.join("|")})\\{([a-z0-9]{12})(?:[ \\t][^{}\\n]*)?\\}`, "g");

  // src/core/filetypes.ts
  var ascii = (head, at, text2) => text2.length <= head.length - at && [...text2].every((ch, i) => head[at + i] === ch.charCodeAt(0));
  var starts = (head, ...bytes) => bytes.every((b, i) => head[i] === b);
  var brand = (head, ...brands) => ascii(head, 4, "ftyp") && brands.some((b) => ascii(head, 8, b));
  var text = (head) => new TextDecoder().decode(head);
  var KNOWN = [
    { type: "image/png", kind: "image", endings: ["png"], inline: true, is: (h) => starts(h, 137, 80, 78, 71, 13, 10, 26, 10) },
    { type: "image/jpeg", kind: "image", endings: ["jpg", "jpeg"], inline: true, is: (h) => starts(h, 255, 216, 255) },
    { type: "image/gif", kind: "image", endings: ["gif"], inline: true, is: (h) => ascii(h, 0, "GIF87a") || ascii(h, 0, "GIF89a") },
    { type: "image/webp", kind: "image", endings: ["webp"], inline: true, is: (h) => ascii(h, 0, "RIFF") && ascii(h, 8, "WEBP") },
    { type: "image/avif", kind: "image", endings: ["avif"], inline: true, is: (h) => brand(h, "avif", "avis") },
    { type: "image/svg+xml", kind: "image", endings: ["svg"], inline: false, is: (h) => /^\uFEFF?\s*(?:<\?xml[^>]*\?>\s*)?(?:<!--[^]*?-->\s*)*(?:<!DOCTYPE svg[^>]*>\s*)?<svg[\s>]/i.test(text(h)) },
    { type: "video/mp4", kind: "video", endings: ["mp4", "m4v"], inline: true, is: (h) => brand(h, "isom", "iso2", "iso5", "iso6", "mp41", "mp42", "avc1", "M4V ", "dash", "mmp4") },
    { type: "video/quicktime", kind: "video", endings: ["mov"], inline: true, is: (h) => brand(h, "qt  ") },
    { type: "video/webm", kind: "video", endings: ["webm"], inline: true, is: (h) => starts(h, 26, 69, 223, 163) },
    { type: "audio/mpeg", kind: "audio", endings: ["mp3"], inline: true, is: (h) => ascii(h, 0, "ID3") || h[0] === 255 && ((h[1] ?? 0) & 224) === 224 },
    { type: "audio/mp4", kind: "audio", endings: ["m4a"], inline: true, is: (h) => brand(h, "M4A ", "isom", "mp42") },
    { type: "audio/wav", kind: "audio", endings: ["wav"], inline: true, is: (h) => ascii(h, 0, "RIFF") && ascii(h, 8, "WAVE") },
    { type: "audio/ogg", kind: "audio", endings: ["ogg", "oga"], inline: true, is: (h) => ascii(h, 0, "OggS") },
    // Opened in a tab, it is shown by the browser's own viewer, and its script runs inside the viewer and reaches nothing of the app's. See ADR 0008 for what the tab's page is.
    // A PDF is shown in place only from the site kept for files (`FILE_ORIGIN`), never from the app's own: see src/worker/files.ts.
    { type: "application/pdf", kind: "file", endings: ["pdf"], inline: false, is: (h) => ascii(h, 0, "%PDF-") }
  ];
  var BY_TYPE = new Map(KNOWN.map((known) => [known.type, known]));
  var KNOWN_TYPES = KNOWN.map((known) => known.type);
  var IMAGE_ENDINGS = [...new Set(KNOWN.flatMap((known) => known.kind === "image" ? known.endings : []))];

  // src/core/parts.ts
  var MIB = 1024 * 1024;
  var PART_BYTES = 80 * MIB;
  var MAX_UPLOAD_BYTES = 25 * 1024 * MIB;

  // extension/src/clip/render.ts
  function excerpt(clip, limit) {
    const parts = [];
    const walk = (blocks) => {
      for (const block of blocks) {
        if (block.type === "paragraph" || block.type === "heading") parts.push(plainInlines(block.inlines));
        else if (block.type === "list") for (const item of block.items) walk(item.blocks);
        else if (block.type === "quote") walk(block.blocks);
      }
    };
    walk(clip.blocks);
    const text2 = parts.join(" ").replace(/\s+/g, " ").trim();
    if (text2.length <= limit) return text2;
    return `${text2.slice(0, limit).trimEnd()}\u2026`;
  }
  function blockImages(clip) {
    const out = [];
    const walk = (blocks) => {
      for (const block of blocks) {
        if (block.type === "image") out.push(block.image);
        else if (block.type === "list") for (const item of block.items) walk(item.blocks);
        else if (block.type === "quote") walk(block.blocks);
      }
    };
    walk(clip.blocks);
    return out;
  }
  function plainInlines(inlines) {
    return inlines.map((inline) => inline.type === "text" || inline.type === "code" ? inline.text : plainInlines(inline.type === "link" ? inline.inlines : inline.inlines)).join("").replace(/\s+/g, " ").trim();
  }

  // extension/src/popup.ts
  var root = document.querySelector("main");
  if (!root) throw new Error("missing root");
  var state = null;
  chrome.storage.onChanged.addListener((_changes, area) => {
    if (area === "session" || area === "local") void refresh();
  });
  void send({ type: "wake" });
  async function refresh() {
    const next = await chrome.runtime.sendMessage({ type: "status" });
    if (next?.auth) {
      state = next;
      paint();
    }
  }
  async function send(message) {
    const next = await chrome.runtime.sendMessage(message);
    if (next?.auth) {
      state = next;
      paint();
    }
  }
  function paint() {
    if (!state) return;
    const focus = document.activeElement instanceof HTMLInputElement ? document.activeElement.id : "";
    const caret = document.activeElement instanceof HTMLInputElement ? document.activeElement.selectionStart : null;
    root.replaceChildren(view(state));
    const input = focus ? document.getElementById(focus) : null;
    if (input instanceof HTMLInputElement) {
      input.focus();
      if (caret != null) input.setSelectionRange(caret, caret);
    }
  }
  function view(current) {
    const wrap = el("div");
    wrap.append(el("h1", "Common Ink"));
    if (current.notice) wrap.append(el("p", current.notice, "notice"));
    if (current.auth.status !== "ready") {
      wrap.append(connect(current));
      if (current.session.status === "review" || current.session.status === "failed") wrap.append(el("p", "The clip is waiting. Sign in, then choose a folder.", "muted"));
      if (current.session.status === "saved") wrap.append(saved(current));
      return wrap;
    }
    const who = current.auth.personName ? `Signed in as ${current.auth.personName}` : "Signed in";
    wrap.append(el("p", current.auth.readOnly ? `${who}. This account can only read.` : who, "muted"));
    const disconnect = el("button", "Sign out", "quiet");
    disconnect.type = "button";
    disconnect.addEventListener("click", () => void send({ type: "disconnect" }));
    wrap.append(disconnect);
    if (current.session.status === "clipping") {
      wrap.append(el("p", "Clipping\u2026"));
      return wrap;
    }
    if (current.session.status === "saved") {
      wrap.append(saved(current));
      return wrap;
    }
    if (current.session.status === "review" || current.session.status === "failed" || current.session.status === "saving") {
      wrap.append(editor(current));
      return wrap;
    }
    wrap.append(idle());
    return wrap;
  }
  function connect(current) {
    const form = el("div");
    form.append(el("p", "Sign in and allow the clipper to save notes as you.", "muted"));
    const host = field("host", "Host", current.auth.host);
    form.append(host.label, host.input);
    const row = el("div", "", "row");
    const button = el("button", "Sign in");
    button.addEventListener("click", () => void send({ type: "signIn", host: host.input.value }));
    row.append(button);
    form.append(row);
    const paste = document.createElement("details");
    paste.className = "paste";
    const summary = document.createElement("summary");
    summary.textContent = "Paste a token";
    const token = field("token", "Token", "", "password");
    token.input.placeholder = "cink_\u2026";
    const tokenRow = el("div", "", "row");
    const use = el("button", "Use token", "quiet");
    use.addEventListener("click", () => void send({ type: "connect", host: host.input.value, token: token.input.value }));
    tokenRow.append(use);
    paste.append(summary, token.label, token.input, tokenRow);
    form.append(paste);
    return form;
  }
  function idle() {
    const block = el("div");
    block.append(el("p", "Clip the page you are reading, or the selection.", "muted"));
    const row = el("div", "", "row");
    const page = el("button", "Clip page");
    const selection = el("button", "Clip selection", "quiet");
    page.addEventListener("click", () => void send({ type: "capture", mode: "page" }));
    selection.addEventListener("click", () => void send({ type: "capture", mode: "selection" }));
    row.append(page, selection);
    block.append(row);
    return block;
  }
  function editor(current) {
    const session = current.session;
    if (session.status !== "review" && session.status !== "failed" && session.status !== "saving") return el("div");
    const saving = session.status === "saving";
    const block = el("div");
    if (session.status === "failed") block.append(el("p", session.message, "notice"));
    const title = field("title", "Title", session.draft.title);
    title.input.disabled = saving;
    title.input.addEventListener("input", () => void send({ type: "setDraft", patch: { title: title.input.value } }));
    block.append(title.label, title.input);
    if (current.auth.workspaces.length > 1) {
      const label = el("label", "Workspace");
      label.htmlFor = "workspace";
      const select = document.createElement("select");
      select.id = "workspace";
      select.disabled = saving;
      for (const workspace of current.auth.workspaces) {
        const option = document.createElement("option");
        option.value = workspace.id;
        option.textContent = workspace.name;
        option.selected = workspace.id === session.draft.workspaceId;
        select.append(option);
      }
      select.addEventListener("change", () => void send({ type: "setDraft", patch: { workspaceId: select.value } }));
      block.append(label, select);
    }
    block.append(folderSelect(current, saving));
    if (session.clip.file && session.status !== "saving") block.append(el("p", `Saves the file ${session.clip.file.name}.`, "muted"));
    else if (session.status !== "saving") block.append(el("p", excerpt(session.clip, 180), "excerpt"));
    const images = session.status === "saving" ? 0 : countImages(session);
    if (images) block.append(el("p", images === 1 ? "1 image will be saved with the note." : `${images} images will be saved with the note.`, "muted"));
    const row = el("div", "", "row");
    const save = el("button", saving ? "Saving\u2026" : "Save");
    save.disabled = saving || current.auth.readOnly || !session.draft.folderId;
    save.addEventListener("click", () => void send({ type: "save" }));
    const dismiss = el("button", "Dismiss", "quiet");
    dismiss.disabled = saving;
    dismiss.addEventListener("click", () => void send({ type: "dismiss" }));
    row.append(save, dismiss);
    block.append(row);
    return block;
  }
  function folderSelect(current, saving) {
    const wrap = el("div");
    const session = current.session;
    if (session.status !== "review" && session.status !== "failed" && session.status !== "saving") return wrap;
    const label = el("label", "Folder");
    label.htmlFor = "folder";
    const select = document.createElement("select");
    select.id = "folder";
    select.disabled = saving || current.folders.status !== "ready";
    const placeholder = document.createElement("option");
    placeholder.value = "";
    placeholder.textContent = current.folders.status === "loading" ? "Loading folders\u2026" : current.folders.status === "error" ? "Could not load folders" : "Choose a folder";
    select.append(placeholder);
    if (current.folders.status === "ready") {
      for (const folder of filterFolders(current.folders.list, "")) {
        const option = document.createElement("option");
        option.value = folder.id;
        option.textContent = folder.path;
        option.selected = folder.id === session.draft.folderId;
        select.append(option);
      }
    }
    if (session.draft.folderId) select.value = session.draft.folderId;
    select.addEventListener("change", () => void send({ type: "setDraft", patch: { folderId: select.value || null } }));
    wrap.append(label, select);
    if (current.folders.status === "error") wrap.append(el("p", current.folders.message, "notice"));
    return wrap;
  }
  function saved(current) {
    if (current.session.status !== "saved") return el("div");
    const block = el("div");
    block.append(el("p", "Saved."));
    const link = document.createElement("a");
    link.href = current.session.note.url;
    link.target = "_blank";
    link.rel = "noreferrer";
    link.textContent = current.session.note.title || "Open note";
    block.append(link);
    const missed = current.session.missed.length;
    if (missed) block.append(el("p", missed === 1 ? "1 image was kept as a link." : `${missed} images were kept as links.`, "muted"));
    const again = el("button", "Clip another", "quiet");
    again.addEventListener("click", () => void send({ type: "dismiss" }));
    const row = el("div", "", "row");
    row.append(again);
    block.append(row);
    return block;
  }
  function countImages(session) {
    return blockImages(session.clip).filter((image) => image.source.kind !== "skip").length;
  }
  function field(id, name, value, type = "text") {
    const label = el("label", name);
    label.htmlFor = id;
    const input = document.createElement("input");
    input.id = id;
    input.type = type;
    input.value = value;
    return { label, input };
  }
  function el(tag, text2 = "", className = "") {
    const node = document.createElement(tag);
    if (text2) node.textContent = text2;
    if (className) node.className = className;
    return node;
  }
})();
