"use strict";
(() => {
  // extension/src/sender.ts
  var answers = (type, sender, ownId) => type === "capture" || sender.id === ownId && sender.url?.startsWith(`chrome-extension://${ownId}/`) === true;

  // src/core/uploadRefs.ts
  var UPLOAD_EMBEDS = ["image", "video", "audio", "file"];
  var REF = new RegExp(`(?<!:)::(${UPLOAD_EMBEDS.join("|")})\\{([a-z0-9]{12})(?:[ \\t][^{}\\n]*)?\\}`, "g");
  var writtenUpload = (embed, id, size) => `::${embed}{${id}${size ? ` ${Math.round(size.width)}x${Math.round(size.height)}` : ""}}`;

  // src/core/filetypes.ts
  var ascii = (head, at, text2) => text2.length <= head.length - at && [...text2].every((ch, i) => head[at + i] === ch.charCodeAt(0));
  var starts = (head, ...bytes) => bytes.every((b, i) => head[i] === b);
  var brand = (head, ...brands) => ascii(head, 4, "ftyp") && brands.some((b) => ascii(head, 8, b));
  var text = (head) => new TextDecoder().decode(head);
  var KNOWN = [
    { type: "image/png", kind: "image", endings: ["png"], inline: true, is: (h) => starts(h, 137, 80, 78, 71, 13, 10, 26, 10) },
    { type: "image/jpeg", kind: "image", endings: ["jpg", "jpeg"], inline: true, is: (h) => starts(h, 255, 216, 255) },
    { type: "image/gif", kind: "image", endings: ["gif"], inline: true, is: (h) => ascii(h, 0, "GIF87a") || ascii(h, 0, "GIF89a") },
    { type: "image/webp", kind: "image", endings: ["webp"], inline: true, is: (h) => ascii(h, 0, "RIFF") && ascii(h, 8, "WEBP") },
    { type: "image/avif", kind: "image", endings: ["avif"], inline: true, is: (h) => brand(h, "avif", "avis") },
    { type: "image/svg+xml", kind: "image", endings: ["svg"], inline: false, is: (h) => /^\uFEFF?\s*(?:<\?xml[^>]*\?>\s*)?(?:<!--[^]*?-->\s*)*(?:<!DOCTYPE svg[^>]*>\s*)?<svg[\s>]/i.test(text(h)) },
    { type: "video/mp4", kind: "video", endings: ["mp4", "m4v"], inline: true, is: (h) => brand(h, "isom", "iso2", "iso5", "iso6", "mp41", "mp42", "avc1", "M4V ", "dash", "mmp4") },
    { type: "video/quicktime", kind: "video", endings: ["mov"], inline: true, is: (h) => brand(h, "qt  ") },
    { type: "video/webm", kind: "video", endings: ["webm"], inline: true, is: (h) => starts(h, 26, 69, 223, 163) },
    { type: "audio/mpeg", kind: "audio", endings: ["mp3"], inline: true, is: (h) => ascii(h, 0, "ID3") || h[0] === 255 && ((h[1] ?? 0) & 224) === 224 },
    { type: "audio/mp4", kind: "audio", endings: ["m4a"], inline: true, is: (h) => brand(h, "M4A ", "isom", "mp42") },
    { type: "audio/wav", kind: "audio", endings: ["wav"], inline: true, is: (h) => ascii(h, 0, "RIFF") && ascii(h, 8, "WAVE") },
    { type: "audio/ogg", kind: "audio", endings: ["ogg", "oga"], inline: true, is: (h) => ascii(h, 0, "OggS") },
    // Opened in a tab, it is shown by the browser's own viewer, and its script runs inside the viewer and reaches nothing of the app's. See ADR 0008 for what the tab's page is.
    // A PDF is shown in place only from the site kept for files (`FILE_ORIGIN`), never from the app's own: see src/worker/files.ts.
    { type: "application/pdf", kind: "file", endings: ["pdf"], inline: false, is: (h) => ascii(h, 0, "%PDF-") }
  ];
  var BYTES = "application/octet-stream";
  var BY_TYPE = new Map(KNOWN.map((known) => [known.type, known]));
  var endingOf = (name) => /\.([A-Za-z0-9]{1,8})$/.exec(name)?.[1]?.toLowerCase() ?? "";
  function typeOf(name, head) {
    const ending = endingOf(name);
    return KNOWN.find((known) => known.endings.includes(ending) && known.is(head))?.type ?? BYTES;
  }
  var kindOf = (type) => BY_TYPE.get(type)?.kind ?? "file";
  var KNOWN_TYPES = KNOWN.map((known) => known.type);
  var IMAGE_ENDINGS = [...new Set(KNOWN.flatMap((known) => known.kind === "image" ? known.endings : []))];

  // src/core/parts.ts
  var MIB = 1024 * 1024;
  var PART_BYTES = 80 * MIB;
  var MAX_UPLOAD_BYTES = 25 * 1024 * MIB;

  // extension/src/clip/images.ts
  function placeId(image) {
    if (image.source.kind === "remote") return image.source.url;
    if (image.source.kind === "inline") return image.key;
    return null;
  }
  function imageBox(uploaded, measured) {
    if (uploaded.width && uploaded.height && uploaded.width > 0 && uploaded.height > 0) return { width: uploaded.width, height: uploaded.height };
    if (measured.width && measured.height && measured.width > 0 && measured.height > 0) return { width: measured.width, height: measured.height };
    return null;
  }
  function planImage(bytes) {
    if (!bytes?.byteLength) return { action: "miss", reason: "unfetched" };
    if (bytes.byteLength > PART_BYTES) return { action: "miss", reason: "too-big" };
    const head = bytes.subarray(0, 65536);
    for (const ending of IMAGE_ENDINGS) {
      const type = typeOf(`clip.${ending}`, head);
      if (kindOf(type) === "image") return { action: "upload", name: `clip.${ending}`, bytes };
    }
    return { action: "miss", reason: "not-image" };
  }
  function inlineBytes(image) {
    if (image.source.kind !== "inline") return null;
    try {
      const binary = atob(image.source.base64);
      const out = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
      return out;
    } catch {
      return null;
    }
  }
  function privateHost(hostname) {
    const host = hostname.toLowerCase().replace(/\.$/, "");
    if (host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local")) return true;
    const v4 = ipv4(host);
    if (v4) return privateV4(v4);
    if (!host.startsWith("[")) return false;
    const v6 = ipv6(host.slice(1, -1));
    if (!v6) return true;
    if (v6.slice(0, 7).every((word) => word === 0) && v6[7] <= 1) return true;
    if (v6.slice(0, 5).every((word) => word === 0) && v6[5] === 65535) return privateV4([v6[6] >> 8, v6[6] & 255, v6[7] >> 8, v6[7] & 255]);
    return (v6[0] & 65024) === 64512 || (v6[0] & 65472) === 65152 || (v6[0] & 65472) === 65216;
  }
  function ipv4(host) {
    const parts = host.split(".");
    if (parts.length !== 4 || !parts.every((part) => /^\d{1,3}$/.test(part))) return null;
    return parts.map(Number);
  }
  function privateV4([a, b]) {
    return a === 0 || a === 10 || a === 127 || a === 169 && b === 254 || a === 172 && b >= 16 && b <= 31 || a === 192 && b === 168 || a === 100 && b >= 64 && b <= 127 || a >= 224;
  }
  function ipv6(address) {
    const [head, tail, more] = address.split("::");
    if (more !== void 0) return null;
    const words = (part) => part ? part.split(":").map((word) => parseInt(word, 16)) : [];
    const front = words(head);
    const back = words(tail);
    const out = tail === void 0 ? front : [...front, ...Array(8 - front.length - back.length).fill(0), ...back];
    return out.length === 8 && out.every((word) => Number.isInteger(word) && word >= 0 && word <= 65535) ? out : null;
  }
  async function readUpTo(response, limit) {
    if (!response.body) return new Uint8Array(0);
    const reader = response.body.getReader();
    const chunks = [];
    let length = 0;
    for (; ; ) {
      const { done, value } = await reader.read();
      if (done) break;
      length += value.byteLength;
      if (length > limit) {
        void reader.cancel();
        return null;
      }
      chunks.push(value);
    }
    const out = new Uint8Array(length);
    let at = 0;
    for (const chunk of chunks) {
      out.set(chunk, at);
      at += chunk.byteLength;
    }
    return out;
  }
  var fetchable = (url) => (url.protocol === "http:" || url.protocol === "https:") && !privateHost(url.hostname);
  async function fetchImage(url, fetchImpl = fetch) {
    let parsed;
    try {
      parsed = new URL(url);
    } catch {
      return null;
    }
    if (!fetchable(parsed)) return null;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 3e4);
    try {
      const response = await fetchImpl(parsed.href, { credentials: "omit", redirect: "manual", signal: controller.signal });
      if (!response.ok) {
        void response.body?.cancel();
        return null;
      }
      const declared = Number(response.headers.get("content-length") ?? "0");
      if (declared > PART_BYTES) {
        void response.body?.cancel();
        return null;
      }
      return await readUpTo(response, PART_BYTES);
    } catch {
      return null;
    } finally {
      clearTimeout(timer);
    }
  }

  // extension/src/clip/render.ts
  function clipToMarkdown(clip, title, placed) {
    const heading = title.replace(/\s+/g, " ").trim() || "Untitled";
    const pageTitle = clip.source.pageTitle.replace(/\s+/g, " ").trim() || clip.source.pageUrl;
    const lines = [`# ${heading}`, "", `[${linkLabel(pageTitle)}](${clip.source.pageUrl}) \xB7 ${clip.source.clippedOn}`];
    let skipped = false;
    const body = [];
    for (const block of clip.blocks) {
      if (!skipped && block.type === "heading" && plainInlines(block.inlines) === heading) {
        skipped = true;
        continue;
      }
      skipped = true;
      const rendered = renderBlock(block, placed, "");
      if (rendered) body.push(rendered);
    }
    const file = clip.file ? placed.document : void 0;
    if (file) body.push(writtenUpload("file", file.id));
    const head = lines.join("\n");
    return body.length ? `${head}

${body.join("\n\n")}
` : `${head}
`;
  }
  function blockImages(clip) {
    const out = [];
    const walk = (blocks) => {
      for (const block of blocks) {
        if (block.type === "image") out.push(block.image);
        else if (block.type === "list") for (const item of block.items) walk(item.blocks);
        else if (block.type === "quote") walk(block.blocks);
      }
    };
    walk(clip.blocks);
    return out;
  }
  function renderBlock(block, placed, indent) {
    switch (block.type) {
      case "heading":
        return `${indent}${"#".repeat(block.level)} ${renderInlines(block.inlines)}`;
      case "paragraph": {
        const bare = bareEmbed(block.inlines);
        return `${indent}${bare ?? renderInlines(block.inlines)}`;
      }
      case "rule":
        return `${indent}---`;
      case "code":
        return renderCode(block.lang, block.text, indent);
      case "quote":
        return renderBlocks(block.blocks, placed, "").split("\n").map((line) => `${indent}> ${line}`.trimEnd()).join("\n");
      case "image":
        return `${indent}${renderImage(block.image, placed)}`;
      case "list":
        return renderList(block, placed, indent);
      case "table":
        return renderTable(block.rows);
    }
  }
  function renderBlocks(blocks, placed, indent) {
    return blocks.map((block) => renderBlock(block, placed, indent)).filter(Boolean).join("\n\n");
  }
  function renderList(block, placed, indent) {
    return block.items.map((item, index) => renderItem(item, marker(block.ordered, block.start, index, item), placed, indent)).join("\n");
  }
  function marker(ordered, start, index, _item) {
    return ordered ? `${start + index}.` : "-";
  }
  function renderItem(item, mark, placed, indent) {
    const [first, ...rest] = item.blocks;
    if (!first) return `${indent}${mark}`;
    const head = first.type === "paragraph" ? renderInlines(first.inlines) : renderBlock(first, placed, "");
    const lines = [`${indent}${mark} ${head}`.trimEnd()];
    for (const block of rest) {
      const rendered = renderBlock(block, placed, `${indent}  `);
      if (rendered) lines.push(rendered);
    }
    return lines.join("\n");
  }
  function renderCode(lang, text2, indent) {
    const fence = "`".repeat(Math.max(3, longestRun(text2) + 1));
    return `${indent}${fence}${lang ?? ""}
${text2}
${indent}${fence}`;
  }
  function longestRun(text2) {
    let best = 0;
    let run = 0;
    for (const ch of text2) {
      run = ch === "`" ? run + 1 : 0;
      if (run > best) best = run;
    }
    return best;
  }
  function renderTable(rows) {
    const header = rows[0];
    if (!header?.length) return "";
    const cell = (inlines) => renderInlines(inlines).replace(/\|/g, "\\|").replace(/\n/g, " ");
    const line = (cells) => `| ${cells.map(cell).join(" | ")} |`;
    return [line(header), `| ${header.map(() => "---").join(" | ")} |`, ...rows.slice(1).map(line)].join("\n");
  }
  function renderImage(image, placed) {
    const id = placeId(image);
    const upload = id ? placed[id] : void 0;
    if (upload) return writtenUpload("image", upload.id, imageBox(upload, image));
    if (image.source.kind === "remote") return `[${linkLabel(image.alt || "image")}](${image.source.url})`;
    return image.alt.trim() || "(image)";
  }
  function renderInlines(inlines) {
    return inlines.map(renderInline).join("");
  }
  function renderInline(inline) {
    switch (inline.type) {
      case "text":
        return inline.text;
      case "link":
        return `[${linkLabel(renderInlines(inline.inlines))}](${inline.href})`;
      case "code": {
        const fence = "`".repeat(Math.max(1, longestRun(inline.text) + 1));
        return `${fence}${inline.text}${fence}`;
      }
      case "strong":
        return `**${renderInlines(inline.inlines)}**`;
      case "em":
        return `*${renderInlines(inline.inlines)}*`;
      case "strike":
        return `~~${renderInlines(inline.inlines)}~~`;
    }
  }
  function bareEmbed(inlines) {
    const only = inlines.length === 1 ? inlines[0] : void 0;
    if (!only || only.type !== "link") return null;
    const text2 = only.inlines.length === 1 ? only.inlines[0] : void 0;
    const label = text2?.type === "text" ? text2.text.trim() : "";
    return label === only.href && embeddable(only.href) ? only.href : null;
  }
  function embeddable(href) {
    try {
      const url = new URL(href);
      const host = url.hostname.replace(/^www\./, "");
      if (host === "youtube.com" || host === "m.youtube.com" || host === "youtu.be") return true;
      if ((host === "x.com" || host === "twitter.com") && /^\/[A-Za-z0-9_]{1,15}\/status\/\d+/.test(url.pathname)) return true;
      return false;
    } catch {
      return false;
    }
  }
  function linkLabel(text2) {
    return text2.replace(/\\/g, "\\\\").replace(/\[/g, "\\[").replace(/\]/g, "\\]");
  }
  function plainInlines(inlines) {
    return inlines.map((inline) => inline.type === "text" || inline.type === "code" ? inline.text : plainInlines(inline.type === "link" ? inline.inlines : inline.inlines)).join("").replace(/\s+/g, " ").trim();
  }

  // extension/src/clip/folders.ts
  function defaultFolder(list, last, workspaceId) {
    const editable = new Set(list.folders.filter((folder) => folder.access === "edit").map((folder) => folder.id));
    if (last && last.workspaceId === workspaceId && editable.has(last.folderId)) return last.folderId;
    if (list.unsortedId && editable.has(list.unsortedId)) return list.unsortedId;
    return list.folders.find((folder) => editable.has(folder.id))?.id ?? null;
  }
  function defaultWorkspace(workspaces, lastId) {
    if (lastId && workspaces.some((workspace) => workspace.id === lastId)) return lastId;
    return workspaces.length === 1 ? workspaces[0].id : workspaces[0]?.id ?? null;
  }

  // src/core/slug.ts
  function noteSlug(title) {
    const slug = title.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+/, "").slice(0, 60).replace(/-+$/, "");
    return slug || "untitled";
  }
  var notePath = (note) => `/note/${note.slug}-${note.id}`;

  // extension/src/clip/note.ts
  function noteUrl(host, note) {
    return `${new URL(host).origin}${notePath(note)}`;
  }

  // extension/src/clip/parse.ts
  var MODES = /* @__PURE__ */ new Set(["page", "selection", "link", "image", "element"]);
  var MAX_NODES = 8e3;
  var MAX_DEPTH = 40;
  var MAX_TEXT = 2e5;
  var CaptureError = class extends Error {
    name = "CaptureError";
    constructor(message) {
      super(message);
    }
  };
  function parseCapture(value) {
    const nodes = { n: 0 };
    if (!isRecord(value)) throw new CaptureError("The clip was empty.");
    const mode = value.mode;
    if (typeof mode !== "string" || !MODES.has(mode)) throw new CaptureError("The clip was empty.");
    const title = typeof value.title === "string" ? value.title.slice(0, 300) : "";
    const source = value.source;
    if (!isRecord(source) || typeof source.pageUrl !== "string" || typeof source.clippedOn !== "string") throw new CaptureError("The clip was empty.");
    const tree = parseTree(value.tree, 0, nodes);
    return {
      mode,
      title,
      source: {
        pageTitle: typeof source.pageTitle === "string" ? source.pageTitle.slice(0, 300) : "",
        pageUrl: source.pageUrl.slice(0, 2e3),
        clippedOn: /^\d{4}-\d{2}-\d{2}$/.test(source.clippedOn) ? source.clippedOn : localDay(/* @__PURE__ */ new Date())
      },
      tree
    };
  }
  function parseTree(value, depth, nodes) {
    if (nodes.n++ > MAX_NODES) throw new CaptureError("This page is too large to clip.");
    if (depth > MAX_DEPTH) throw new CaptureError("This page is too large to clip.");
    if (!isRecord(value) || typeof value.tag !== "string") throw new CaptureError("The clip was empty.");
    const attrs = {};
    if (isRecord(value.attrs)) {
      for (const [key, item] of Object.entries(value.attrs)) {
        if (typeof item === "string" && key.length < 40) attrs[key] = item.slice(0, 8e3);
      }
    }
    const children = [];
    if (Array.isArray(value.children)) {
      for (const child of value.children) children.push(parseTree(child, depth + 1, nodes));
    }
    const text2 = typeof value.text === "string" ? value.text.slice(0, MAX_TEXT) : "";
    return { tag: value.tag.slice(0, 40).toLowerCase(), attrs, children, text: text2 };
  }
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function localDay(now) {
    const month = String(now.getMonth() + 1).padStart(2, "0");
    const day = String(now.getDate()).padStart(2, "0");
    return `${now.getFullYear()}-${month}-${day}`;
  }

  // extension/src/ink/client.ts
  var InkError = class extends Error {
    constructor(code, message) {
      super(message);
      this.code = code;
    }
    code;
    name = "InkError";
  };
  function createInk(auth, fetchImpl = fetch) {
    const origin = originOf(auth.host);
    let id = 0;
    async function request(url, init) {
      if (new URL(url).origin !== origin) throw new InkError("invalid", "Refusing to send the token to another host.");
      const headers = new Headers(init.headers);
      headers.set("Authorization", `Bearer ${auth.token}`);
      const response = await fetchImpl(url, { ...init, headers });
      if (response.status === 401) throw new InkError("unauthorized", "That sign-in was refused. Sign in again.");
      return response;
    }
    async function tool(name, args) {
      const response = await request(`${origin}/mcp`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ jsonrpc: "2.0", id: ++id, method: "tools/call", params: { name, arguments: args } })
      });
      const body = await response.json().catch(() => null);
      const result = body?.result;
      if (!result) throw new InkError("invalid", body?.error?.message || "Common Ink did not answer.");
      const text2 = result.content?.[0]?.text ?? "";
      if (result.isError) {
        const match = /^([a-z_]+): ([\s\S]*)$/.exec(text2);
        throw new InkError(match?.[1] ?? "invalid", match?.[2] ?? text2);
      }
      return JSON.parse(text2);
    }
    return {
      async listWorkspaces() {
        const value = await tool("list_workspaces", {});
        const workspaces = Array.isArray(value?.workspaces) ? value.workspaces.filter(isWorkspace) : [];
        return {
          person: { id: value?.person?.id ?? "", name: value?.person?.name ?? "" },
          workspaces,
          readOnly: value?.readOnly === true,
          folderIds: Array.isArray(value?.folderIds) ? value.folderIds.filter((item) => typeof item === "string") : null
        };
      },
      async listFolders(workspaceId) {
        const value = await tool("list_folders", { workspaceId });
        const folders = Array.isArray(value?.folders) ? value.folders.filter(isFolder) : [];
        const unsortedId = typeof value?.unsortedId === "string" ? value.unsortedId : null;
        return { unsortedId, folders };
      },
      async createNote(input) {
        const value = await tool("create_note", {
          workspaceId: input.workspaceId,
          folderId: input.folderId,
          text: input.text,
          linkTitles: "keep",
          mentionNames: "keep",
          writeId: input.writeId
        });
        if (typeof value.id !== "string") throw new InkError("invalid", "Common Ink did not return the note.");
        const title = typeof value.title === "string" ? value.title : "";
        return {
          id: value.id,
          slug: typeof value.slug === "string" && value.slug ? value.slug : noteSlug(title),
          title,
          folderId: typeof value.folderId === "string" ? value.folderId : input.folderId
        };
      },
      async uploadImage(input) {
        const response = await request(`${origin}/api/workspaces/${input.workspaceId}/uploads`, {
          method: "POST",
          headers: {
            "Content-Type": "application/octet-stream",
            "X-Ink-Upload": encodeURIComponent(JSON.stringify({ name: input.name, folderId: input.folderId }))
          },
          body: new Blob([input.bytes.slice()])
        });
        if (!response.ok) {
          const body = await response.json().catch(() => null);
          throw new InkError(body?.error ?? "invalid", body?.message || "The image could not be uploaded.");
        }
        const upload = await response.json();
        if (upload.kind !== "image" || typeof upload.id !== "string") throw new InkError("not-image", "The file was not an image.");
        return { id: upload.id, width: numberOrNull(upload.width), height: numberOrNull(upload.height) };
      },
      async uploadFile(input) {
        const response = await request(`${origin}/api/workspaces/${input.workspaceId}/uploads`, {
          method: "POST",
          headers: {
            "Content-Type": "application/octet-stream",
            "X-Ink-Upload": encodeURIComponent(JSON.stringify({ name: input.name, folderId: input.folderId }))
          },
          body: new Blob([input.bytes.slice()])
        });
        if (!response.ok) {
          const body = await response.json().catch(() => null);
          throw new InkError(body?.error ?? "invalid", body?.message || "The file could not be uploaded.");
        }
        const upload = await response.json();
        if (typeof upload.id !== "string") throw new InkError("invalid", "Common Ink did not return the file.");
        return { id: upload.id };
      },
      async signOut() {
        await request(`${origin}/clipper/revoke`, { method: "POST", signal: AbortSignal.timeout(5e3) });
      }
    };
  }
  function originOf(host) {
    let url;
    try {
      url = new URL(host.includes("://") ? host : `https://${host}`);
    } catch {
      throw new InkError("invalid", "The host must be an http(s) address.");
    }
    if (url.protocol !== "https:" && url.protocol !== "http:") throw new InkError("invalid", "The host must be an http(s) address.");
    return url.origin;
  }
  function isWorkspace(value) {
    return !!value && typeof value === "object" && typeof value.id === "string" && typeof value.name === "string";
  }
  function isFolder(value) {
    if (!value || typeof value !== "object") return false;
    const folder = value;
    return typeof folder.id === "string" && typeof folder.name === "string" && typeof folder.path === "string" && (folder.access === "edit" || folder.access === "view");
  }
  function numberOrNull(value) {
    return typeof value === "number" && value > 0 ? value : null;
  }

  // extension/src/clip/document.ts
  var ENDING = /\.(pdf|json|csv|txt|xml|md|markdown)$/i;
  function urlLooksLikeDocument(url) {
    try {
      return ENDING.test(new URL(url).pathname);
    } catch {
      return false;
    }
  }
  function isDocument(url, mime, name) {
    const type = mime.split(";")[0]?.trim().toLowerCase() ?? "";
    if (type.startsWith("text/html") || type === "application/xhtml+xml") return false;
    if (type.startsWith("image/") || type.startsWith("video/") || type.startsWith("audio/")) return false;
    if (type === "application/pdf" || type === "application/json" || type === "text/json" || type === "text/csv") return true;
    const named = ENDING.test(name) || urlLooksLikeDocument(url);
    if (!named) return false;
    return type === "" || type === "application/octet-stream" || type === "text/plain" || type === "application/xml" || type === "text/xml" || type === "text/markdown";
  }
  async function fetchDocument(url, fetchImpl = fetch) {
    let response;
    try {
      response = await fetchImpl(url, { credentials: "include", signal: AbortSignal.timeout(2e4) });
    } catch {
      return null;
    }
    if (!response.ok) {
      await response.body?.cancel();
      return null;
    }
    const mime = response.headers.get("content-type") ?? "";
    const name = fileName(url, response.headers.get("content-disposition"), mime);
    if (!isDocument(url, mime, name)) {
      await response.body?.cancel();
      return null;
    }
    const declared = Number(response.headers.get("content-length") ?? "");
    if (Number.isFinite(declared) && declared > PART_BYTES) {
      await response.body?.cancel();
      return "too-big";
    }
    const bytes = new Uint8Array(await response.arrayBuffer());
    if (!bytes.byteLength) return null;
    if (bytes.byteLength > PART_BYTES) return "too-big";
    return { name, title: fileTitle(name, bytes), url, bytes };
  }
  function fileName(url, disposition, mime) {
    const star = /filename\*=(?:UTF-8|utf-8)''([^;]+)/.exec(disposition ?? "");
    if (star?.[1]) {
      try {
        const decoded = decodeURIComponent(star[1]).replace(/[/\\]/g, "").trim();
        if (decoded) return decoded;
      } catch {
      }
    }
    const plain2 = /filename="?([^";]+)"?/i.exec(disposition ?? "");
    const named = plain2?.[1]?.replace(/[/\\]/g, "").trim();
    if (named) return named;
    try {
      const path = decodeURIComponent(new URL(url).pathname.split("/").filter(Boolean).pop() ?? "");
      if (path && path.includes(".")) return path;
    } catch {
    }
    if (mime.toLowerCase().includes("pdf")) return "document.pdf";
    if (mime.toLowerCase().includes("json")) return "document.json";
    return "document";
  }
  function fileTitle(name, bytes) {
    if (name.toLowerCase().endsWith(".pdf") && ascii2(bytes, 0, "%PDF-")) {
      const titled = pdfTitle(bytes);
      if (titled) return titled;
    }
    const bare = name.replace(/\.[A-Za-z0-9]{1,8}$/, "").replace(/[_-]+/g, " ").trim();
    return bare || name;
  }
  function pdfTitle(bytes) {
    const text2 = new TextDecoder("latin1").decode(bytes.subarray(0, Math.min(bytes.byteLength, 2e5)));
    const match = /\/Title\s*\(([^)]{1,300})\)/.exec(text2);
    if (!match?.[1]) return null;
    const raw = match[1].replace(/\\([()\\nrt])/g, (_, ch) => ch === "n" || ch === "r" || ch === "t" ? " " : ch);
    const cleaned = raw.replace(/[^\x20-\x7e]/g, "").replace(/\s+/g, " ").trim();
    return cleaned.length >= 2 ? cleaned.slice(0, 200) : null;
  }
  function ascii2(bytes, at, text2) {
    return text2.length <= bytes.length - at && [...text2].every((ch, i) => bytes[at + i] === ch.charCodeAt(0));
  }

  // extension/src/session.ts
  var CHOOSE = "Choose a folder.";
  var FRESH_MS = 1500;
  function settle(session, touched, now) {
    if (session.status === "saving" || session.status === "clipping" || session.status === "idle") return session;
    if (session.status === "saved") return { status: "idle" };
    return now - touched > FRESH_MS ? { status: "idle" } : session;
  }
  function reduce(session, event) {
    switch (event.type) {
      case "clipping":
        return session.status === "saving" ? session : { status: "clipping" };
      case "captured":
        if (session.status === "saving") return session;
        return { status: "review", clip: event.clip, draft: event.defaults };
      case "draft": {
        if (session.status !== "review" && session.status !== "failed") return session;
        return { ...session, draft: { ...session.draft, ...event.patch } };
      }
      case "save":
        return startSave(session);
      case "placed":
        if (session.status !== "saving") return session;
        return { ...session, placed: { ...session.placed, [event.id]: event.upload } };
      case "miss":
        if (session.status !== "saving") return session;
        return { ...session, missed: [...session.missed, event.miss] };
      case "noted":
        if (session.status !== "saving") return session;
        return { ...session, note: event.note };
      case "created":
        if (session.status !== "saving") return session;
        return { status: "saved", note: event.note, missed: session.missed, draft: session.draft };
      case "failed":
        if (session.status === "clipping") return { status: "idle" };
        if (session.status !== "saving" && session.status !== "review") return session;
        return {
          status: "failed",
          clip: session.clip,
          draft: session.draft,
          placed: session.status === "saving" ? session.placed : {},
          missed: session.status === "saving" ? session.missed : [],
          createKey: session.status === "saving" ? session.createKey : null,
          message: event.message
        };
      case "dismiss":
        if (session.status === "saving") return session;
        return { status: "idle" };
    }
  }
  function startSave(session) {
    if (session.status === "saving" || session.status === "saved" || session.status === "idle" || session.status === "clipping") return session;
    if (!session.draft.workspaceId || !session.draft.folderId) {
      return {
        status: "failed",
        clip: session.clip,
        draft: session.draft,
        placed: session.status === "failed" ? session.placed : {},
        missed: session.status === "failed" ? session.missed : [],
        createKey: session.status === "failed" ? session.createKey : null,
        message: CHOOSE
      };
    }
    const draft = { title: session.draft.title, workspaceId: session.draft.workspaceId, folderId: session.draft.folderId };
    const createKey = session.status === "failed" && session.createKey ? session.createKey : crypto.randomUUID();
    if (session.status === "failed") return { status: "saving", clip: session.clip, draft, placed: session.placed, missed: [], createKey, note: null };
    return { status: "saving", clip: session.clip, draft, placed: {}, missed: [], createKey, note: null };
  }

  // extension/src/clip/tree.ts
  var DROP = /* @__PURE__ */ new Set(["script", "style", "noscript", "template", "iframe", "canvas", "form", "button", "svg", "head", "meta", "link", "object", "embed", "input"]);
  var UNWRAP = /* @__PURE__ */ new Set(["div", "section", "article", "main", "body", "header", "footer", "nav", "aside", "span", "font", "center", "html", "#fragment"]);
  var BLOCK = /* @__PURE__ */ new Set(["p", "div", "section", "article", "main", "header", "footer", "nav", "aside", "ul", "ol", "pre", "table", "blockquote", "h1", "h2", "h3", "h4", "h5", "h6", "figure", "hr", "address", "form"]);
  var INLINE_IMAGE_CAP = 1e6;
  var INLINE_CLIP_CAP = 4e6;
  function clipFromTree(capture) {
    return { mode: capture.mode, title: capture.title, source: capture.source, blocks: readTree(capture.tree) };
  }
  function readTree(root) {
    return blocksFrom(root, { n: 0, inline: 0 });
  }
  function blocksFrom(node, images) {
    if (node.tag === "#text") {
      const text2 = keepEdgeSpace(node.text);
      return text2.trim() ? [{ type: "paragraph", inlines: [{ type: "text", text: text2.trim() }] }] : [];
    }
    if (DROP.has(node.tag)) return [];
    if (node.tag === "hr") return [{ type: "rule" }];
    if (node.tag === "img") {
      const image = blockImage(node, images);
      return image ? [{ type: "image", image }] : [];
    }
    if (/^h[1-6]$/.test(node.tag)) {
      const level = Number(node.tag[1]);
      const inlines = trimInlines(inlinesFrom(node));
      return inlines.length ? [{ type: "heading", level, inlines }] : [];
    }
    if (node.tag === "p" || node.tag === "figcaption" || node.tag === "address") return paragraphBlocks(node, images);
    if (node.tag === "pre") return [codeBlock(node)];
    if (node.tag === "blockquote") {
      const blocks = childrenBlocks(node, images);
      return blocks.length ? [{ type: "quote", blocks }] : [];
    }
    if (node.tag === "ul" || node.tag === "ol") return [listFrom(node, images)];
    if (node.tag === "table") {
      const rows = tableRows(node);
      return rows.length ? [{ type: "table", rows }] : [];
    }
    if (node.tag === "figure") return childrenBlocks(node, images);
    if (node.tag === "li") return itemBlocks(node, images);
    if (UNWRAP.has(node.tag) || !BLOCK.has(node.tag)) {
      return childrenArePhrasing(node) ? paragraphBlocks(node, images) : childrenBlocks(node, images);
    }
    return childrenBlocks(node, images);
  }
  function childrenBlocks(node, images) {
    return node.children.flatMap((child) => blocksFrom(child, images));
  }
  function childrenArePhrasing(node) {
    return node.children.every((child) => child.tag === "#text" || !BLOCK.has(child.tag) && !DROP.has(child.tag) && child.tag !== "div" && childrenArePhrasing(child));
  }
  function paragraphBlocks(node, images) {
    const parts = splitPhrasing(node, images, false);
    const blocks = [];
    for (const part of parts) {
      if (part.kind === "image") blocks.push({ type: "image", image: part.image });
      else {
        const inlines = trimInlines(part.inlines);
        if (inlines.length) blocks.push({ type: "paragraph", inlines });
      }
    }
    return blocks;
  }
  function splitPhrasing(node, images, inAnchor) {
    const parts = [];
    let current = [];
    const flush = () => {
      if (current.length) parts.push({ kind: "inlines", inlines: current });
      current = [];
    };
    const pushInline = (inline) => {
      if (inline) current.push(inline);
    };
    const visit = (n, anchor) => {
      if (n.tag === "#text") {
        pushInline(textInline(n.text));
        return;
      }
      if (DROP.has(n.tag) || n.tag === "br") {
        if (n.tag === "br") pushInline({ type: "text", text: " " });
        return;
      }
      if (n.tag === "img") {
        if (anchor) {
          pushInline(imageLink(n));
          return;
        }
        const image = blockImage(n, images);
        if (!image) return;
        flush();
        parts.push({ kind: "image", image });
        return;
      }
      if (n.tag === "a") {
        const href = n.attrs.href;
        const nested = splitPhrasing(n, images, true);
        const inlines = trimInlines(nested.flatMap((part) => part.kind === "inlines" ? part.inlines : []));
        if (!href) {
          for (const inline of inlines) pushInline(inline.type === "link" ? { type: "text", text: plain(inline.inlines) } : inline);
          return;
        }
        const label = trimInlines(inlines.map((inline) => inline.type === "link" ? { type: "text", text: plain(inline.inlines) } : inline));
        pushInline(label.length ? { type: "link", href, inlines: label } : null);
        return;
      }
      if (n.tag === "strong" || n.tag === "b" || n.tag === "em" || n.tag === "i" || n.tag === "s" || n.tag === "strike" || n.tag === "del" || n.tag === "code") {
        const nested = splitPhrasing(n, images, anchor);
        for (const part of nested) {
          if (part.kind === "image") {
            flush();
            parts.push(part);
            continue;
          }
          for (const inline of wrap(n.tag, part.inlines)) pushInline(inline);
        }
        return;
      }
      for (const child of n.children) visit(child, anchor);
    };
    for (const child of node.children) visit(child, inAnchor);
    flush();
    return parts;
  }
  function wrap(tag, inlines) {
    const trimmed = inlines;
    if (!trimmed.length) return [];
    if (tag === "strong" || tag === "b") return [{ type: "strong", inlines: trimmed }];
    if (tag === "em" || tag === "i") return [{ type: "em", inlines: trimmed }];
    if (tag === "s" || tag === "strike" || tag === "del") return [{ type: "strike", inlines: trimmed }];
    if (tag === "code") {
      const text2 = plain(trimmed);
      return text2 ? [{ type: "code", text: text2 }] : [];
    }
    return trimmed;
  }
  function inlinesFrom(node) {
    const parts = splitPhrasing(node, { n: 0, inline: 0 }, true);
    return parts.flatMap((part) => part.kind === "inlines" ? part.inlines : []);
  }
  function imageLink(node) {
    const alt = node.attrs.alt?.trim() || "image";
    const src = node.attrs.src;
    if (!src) return { type: "text", text: alt };
    return { type: "link", href: src, inlines: [{ type: "text", text: alt }] };
  }
  function blockImage(node, images) {
    const alt = node.attrs.alt ?? "";
    const width = positive(node.attrs.width);
    const height = positive(node.attrs.height);
    const key = `i${++images.n}`;
    const skip = node.attrs["data-clip-skip"];
    if (skip) return { key, alt, width, height, source: { kind: "skip", reason: skip } };
    const src = node.attrs.src ?? "";
    if (!src) return { key, alt, width, height, source: { kind: "skip", reason: "unreadable" } };
    if (src.startsWith("data:")) {
      const parsed = dataImage(src);
      if (!parsed) return { key, alt, width, height, source: { kind: "skip", reason: "unreadable" } };
      const bytes = Math.floor(parsed.base64.length * 3 / 4);
      if (bytes > INLINE_IMAGE_CAP || images.inline + bytes > INLINE_CLIP_CAP) {
        return { key, alt, width, height, source: { kind: "skip", reason: "inline-too-big" } };
      }
      images.inline += bytes;
      return { key, alt, width, height, source: { kind: "inline", mediaType: parsed.mediaType, base64: parsed.base64 } };
    }
    if (!/^https?:\/\//i.test(src)) return { key, alt, width, height, source: { kind: "skip", reason: "unsafe" } };
    return { key, alt, width, height, source: { kind: "remote", url: src } };
  }
  function dataImage(src) {
    const match = /^data:([^;,]+);base64,([A-Za-z0-9+/=\s]+)$/i.exec(src);
    if (!match) return null;
    return { mediaType: match[1], base64: match[2].replace(/\s+/g, "") };
  }
  function codeBlock(node) {
    const code = node.children.find((child) => child.tag === "code") ?? node;
    const lang = language(code.attrs.class ?? node.attrs.class ?? "");
    return { type: "code", lang, text: rawText(code).replace(/\n$/, "") };
  }
  function language(className) {
    return /(?:^|\s)(?:language|lang)-([A-Za-z0-9_+-]+)/.exec(className)?.[1] ?? null;
  }
  function rawText(node) {
    if (node.tag === "#text") return node.text;
    return node.children.map(rawText).join("");
  }
  function listFrom(node, images) {
    const ordered = node.tag === "ol";
    const start = positive(node.attrs.start) ?? 1;
    const items = node.children.filter((child) => child.tag === "li").map((li) => listItem(li, images));
    return { type: "list", ordered, start, items };
  }
  function listItem(li, images) {
    return { checked: null, blocks: itemBlocks(li, images) };
  }
  function itemBlocks(node, images) {
    return childrenArePhrasing(node) ? paragraphBlocks(node, images) : childrenBlocks(node, images);
  }
  function tableRows(table) {
    const rows = [];
    const walk = (node, top) => {
      for (const child of node.children) {
        if (child.tag === "tr") rows.push(child);
        else if (child.tag !== "table" || top) walk(child, false);
      }
    };
    walk(table, true);
    return rows.map((row) => row.children.filter((cell) => cell.tag === "td" || cell.tag === "th").map((cell) => trimInlines(inlinesFrom(cell))));
  }
  function textInline(text2) {
    const collapsed = keepEdgeSpace(text2);
    return collapsed ? { type: "text", text: collapsed } : null;
  }
  function keepEdgeSpace(text2) {
    if (!text2) return "";
    const lead = /^\s/.test(text2);
    const trail = /\s$/.test(text2);
    const core = text2.replace(/\s+/g, " ").trim();
    if (!core) return lead || trail ? " " : "";
    return `${lead ? " " : ""}${core}${trail ? " " : ""}`;
  }
  function trimInlines(inlines) {
    const copy = inlines.map((inline) => ({ ...inline }));
    const trimEnd = (inline, side) => {
      if (inline.type !== "text") return inline;
      const text2 = side === "lead" ? inline.text.replace(/^\s+/, "") : inline.text.replace(/\s+$/, "");
      return { type: "text", text: text2 };
    };
    while (copy.length && copy[0]?.type === "text" && !copy[0].text.trim()) copy.shift();
    while (copy.length) {
      const last = copy.at(-1);
      if (last?.type !== "text" || last.text.trim()) break;
      copy.pop();
    }
    if (copy[0]) copy[0] = trimEnd(copy[0], "lead");
    if (copy.at(-1)) copy[copy.length - 1] = trimEnd(copy.at(-1), "trail");
    return copy.filter((inline) => inline.type !== "text" || inline.text.length > 0);
  }
  function plain(inlines) {
    return inlines.map((inline) => inline.type === "text" || inline.type === "code" ? inline.text : plain(inline.type === "link" ? inline.inlines : inline.inlines)).join("");
  }
  function positive(value) {
    if (!value) return null;
    const n = Number(value);
    return Number.isFinite(n) && n > 0 ? Math.round(n) : null;
  }

  // extension/src/clip/tweet.ts
  function tweetTarget(value) {
    let url;
    try {
      url = new URL(value);
    } catch {
      return null;
    }
    const host = url.hostname.replace(/^(www|mobile)\./, "");
    if (host !== "x.com" && host !== "twitter.com") return null;
    const match = /^\/([A-Za-z0-9_]{1,15})\/status\/(\d{1,25})\/?$/.exec(url.pathname);
    if (!match) return null;
    return { handle: match[1], id: match[2], permalink: `https://x.com/${match[1]}/status/${match[2]}` };
  }
  function tweetFromOembed(html, permalink) {
    const target = tweetTarget(permalink);
    const paragraph2 = /<p\b[^>]*>([\s\S]*?)<\/p>/i.exec(html);
    if (!paragraph2 || !target) return null;
    const text2 = plainHtml(paragraph2[1] ?? "");
    if (!text2) return null;
    const byline = /(?:&mdash;|—)\s*([^<(\n]+?)\s*\(@([A-Za-z0-9_]{1,15})\)/i.exec(html);
    const dated = /<a\b[^>]*href="[^"]*\/status\/\d+[^"]*"[^>]*>([\s\S]*?)<\/a>/i.exec(html);
    const images = [...html.matchAll(/<img\b[^>]*src="(https?:\/\/[^"]+)"/gi)].map((match) => match[1]).filter((src) => !/profile_images|emoji/.test(src));
    return {
      author: (byline?.[1] ?? target.handle).replace(/\s+/g, " ").trim(),
      handle: byline?.[2] ?? target.handle,
      text: text2,
      date: dated ? plainHtml(dated[1] ?? "") || null : null,
      permalink: target.permalink,
      images
    };
  }
  function tweetBlocks(tweet) {
    const blocks = [
      { type: "paragraph", inlines: [strong(tweet.author), { type: "text", text: ` (@${tweet.handle})` }] },
      { type: "paragraph", inlines: [{ type: "text", text: tweet.text }] }
    ];
    if (tweet.date) blocks.push({ type: "paragraph", inlines: [{ type: "text", text: tweet.date }] });
    blocks.push({ type: "paragraph", inlines: [link(tweet.permalink, tweet.permalink)] });
    tweet.images.forEach((url, index) => {
      blocks.push({
        type: "image",
        image: { key: `t${index + 1}`, alt: "", width: null, height: null, source: { kind: "remote", url } }
      });
    });
    return blocks;
  }
  function clipWithTweet(clip, tweet) {
    const title = tweet.text.replace(/\s+/g, " ").trim().slice(0, 80) || clip.title;
    return { ...clip, title, blocks: tweetBlocks(tweet) };
  }
  async function fetchOembed(permalink, fetchImpl = fetch) {
    try {
      const response = await fetchImpl(`https://publish.twitter.com/oembed?omit_script=1&dnt=true&url=${encodeURIComponent(permalink)}`, { credentials: "omit", signal: AbortSignal.timeout(8e3) });
      if (!response.ok) return null;
      const body = await response.json();
      return typeof body.html === "string" ? body.html : null;
    } catch {
      return null;
    }
  }
  function strong(text2) {
    return { type: "strong", inlines: [{ type: "text", text: text2 }] };
  }
  function link(href, text2) {
    return { type: "link", href, inlines: [{ type: "text", text: text2 }] };
  }
  function plainHtml(html) {
    const withLinks = html.replace(/<a\b[^>]*href="([^"]+)"[^>]*>[\s\S]*?<\/a>/gi, " $1 ");
    const text2 = withLinks.replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]+>/g, "");
    return decode(text2).replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").replace(/[ \t]{2,}/g, " ").trim();
  }
  function decode(text2) {
    return text2.replace(/&#(\d+);/g, (_, code) => String.fromCodePoint(Number(code))).replace(/&#x([0-9a-f]+);/gi, (_, code) => String.fromCodePoint(Number.parseInt(code, 16))).replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&");
  }

  // extension/src/clip/video.ts
  var GENERIC = /enjoy the videos and music you love/i;
  function watchTarget(value) {
    let url;
    try {
      url = new URL(value);
    } catch {
      return null;
    }
    const host = url.hostname.replace(/^(www|m)\./, "");
    if (host === "youtu.be" && url.pathname.length > 1) return `https://www.youtube.com/watch?v=${url.pathname.slice(1).split("/")[0]}`;
    if (host === "youtube.com" && url.pathname === "/watch" && url.searchParams.get("v")) return `https://www.youtube.com/watch?v=${url.searchParams.get("v")}`;
    return null;
  }
  function thinVideo(title, text2) {
    const name = title.replace(/\s+/g, " ").trim();
    return !name || name === "Video" || name === "YouTube" || GENERIC.test(text2) || GENERIC.test(name);
  }
  function clipWithVideo(clip, card, watch) {
    const blocks = [];
    if (card.author) blocks.push(paragraph([{ type: "text", text: card.author }]));
    blocks.push(...descriptionOf(clip, watch));
    blocks.push(paragraph([{ type: "link", href: watch, inlines: [{ type: "text", text: watch }] }]));
    return { ...clip, title: card.title || clip.title, blocks };
  }
  function descriptionOf(clip, watch) {
    return clip.blocks.filter((block) => {
      if (block.type !== "paragraph") return false;
      const text2 = paragraphText(block);
      if (!text2 || text2 === watch || text2 === clip.source.pageUrl) return false;
      if (GENERIC.test(text2) || text2 === "Video" || text2 === "YouTube") return false;
      return true;
    });
  }
  function paragraphText(block) {
    if (block.type !== "paragraph") return "";
    const parts = [];
    const walk = (inlines) => {
      for (const inline of inlines) {
        if (inline.type === "text" || inline.type === "code") parts.push(inline.text);
        else walk(inline.inlines);
      }
    };
    walk(block.inlines);
    return parts.join(" ").replace(/\s+/g, " ").trim();
  }
  async function fetchWatch(watch, fetchImpl = fetch) {
    try {
      const response = await fetchImpl(`https://www.youtube.com/oembed?format=json&url=${encodeURIComponent(watch)}`, { credentials: "omit", signal: AbortSignal.timeout(8e3) });
      if (!response.ok) return null;
      const body = await response.json();
      if (typeof body.title !== "string" || !body.title.trim()) return null;
      return { title: body.title.replace(/\s+/g, " ").trim(), author: typeof body.author_name === "string" ? body.author_name.replace(/\s+/g, " ").trim() : "" };
    } catch {
      return null;
    }
  }
  function paragraph(inlines) {
    return { type: "paragraph", inlines };
  }

  // extension/src/store.ts
  var NOTE_TEXT_LIMIT = 5e5;
  var PERSIST_LIMIT = 8e6;
  var CLIP_MS = 12e3;
  function createClipper() {
    let session = { status: "idle" };
    let auth = null;
    let personName = null;
    let readOnly = false;
    let rejected = false;
    let workspaces = [];
    let folders = { status: "empty" };
    let notice = null;
    let lastPlace = null;
    let touched = 0;
    const fileBytes = /* @__PURE__ */ new Map();
    let queue = Promise.resolve();
    const enqueue = (job) => {
      const run = queue.then(job, job);
      queue = run.then(
        () => void 0,
        () => void 0
      );
      return run;
    };
    async function load() {
      const local = await chrome.storage.local.get(["auth", "lastPlace"]);
      auth = isAuth(local.auth) ? local.auth : null;
      lastPlace = isPlace(local.lastPlace) ? local.lastPlace : null;
      const stored = await chrome.storage.session.get(["pending"]);
      if (isSession(stored.pending)) session = stored.pending;
      if (auth) {
        try {
          const list = await createInk(auth).listWorkspaces();
          personName = list.person.name;
          readOnly = list.readOnly;
          workspaces = list.workspaces;
          rejected = false;
        } catch {
          rejected = true;
        }
      }
      if (session.status === "saving") await commit();
    }
    async function persist() {
      const text2 = JSON.stringify(session);
      if (text2.length >= PERSIST_LIMIT) {
        await chrome.storage.session.remove(["pending"]);
        return;
      }
      await chrome.storage.session.set({ pending: session });
    }
    function view() {
      return {
        auth: {
          host: auth?.host ?? "https://commonink.app",
          status: !auth ? "missing" : rejected ? "rejected" : "ready",
          personName,
          readOnly,
          workspaces
        },
        session,
        folders,
        notice
      };
    }
    async function ensureFolders(workspaceId, force = false) {
      if (!auth || rejected || !workspaceId) return;
      if (!force && folders.status === "ready" && folders.workspaceId === workspaceId) return;
      if (!force && folders.status === "loading" && folders.workspaceId === workspaceId) return;
      folders = { status: "loading", workspaceId };
      try {
        const list = await createInk(auth).listFolders(workspaceId);
        folders = { status: "ready", workspaceId, list };
        if ((session.status === "review" || session.status === "failed") && session.draft.workspaceId === workspaceId && !session.draft.folderId) {
          session = reduce(session, { type: "draft", patch: { folderId: defaultFolder(list, lastPlace, workspaceId) } });
          await persist();
        }
      } catch (err) {
        folders = { status: "error", workspaceId, message: err instanceof InkError ? err.message : "Could not load folders." };
      }
    }
    function defaultsFor(title) {
      const workspaceId = defaultWorkspace(workspaces, lastPlace?.workspaceId ?? null);
      const list = folders.status === "ready" && folders.workspaceId === workspaceId ? folders.list : null;
      return { title, workspaceId, folderId: workspaceId && list ? defaultFolder(list, lastPlace, workspaceId) : null };
    }
    async function take(capture) {
      try {
        const parsed = parseCapture(capture);
        const clip = await maybeVideo(await maybeTweet(clipFromTree(parsed)));
        const draft = defaultsFor(clip.title || parsed.title);
        touched = Date.now();
        session = reduce(session, { type: "captured", clip, defaults: { ...draft, title: clip.title || parsed.title || "Untitled" } });
        notice = null;
        await persist();
        await ensureFolders(session.status === "review" ? session.draft.workspaceId : null, true);
        if (session.status === "review" && !session.draft.folderId && folders.status === "ready") {
          session = reduce(session, { type: "draft", patch: { folderId: defaultFolder(folders.list, lastPlace, folders.workspaceId) } });
          await persist();
        }
      } catch (err) {
        notice = err instanceof Error ? err.message : "Could not clip this page.";
        if (session.status === "clipping") session = { status: "idle" };
        await persist();
      }
      return view();
    }
    async function commit() {
      if (session.status !== "saving" || !auth) return;
      if (session.note) {
        const draft2 = session.draft;
        session = reduce(session, { type: "created", note: { ...session.note, url: noteUrl(auth.host, session.note) } });
        lastPlace = { workspaceId: draft2.workspaceId, folderId: draft2.folderId };
        await chrome.storage.local.set({ lastPlace });
        await chrome.action.setBadgeText({ text: "" });
        await persist();
        return;
      }
      const ink = createInk(auth);
      const draft = session.draft;
      if (session.clip.file && !session.placed.document) {
        const file = session.clip.file;
        const bytes = fileBytes.get(file.url) ?? await refetchDocument(file.url);
        if (!bytes) {
          session = reduce(session, { type: "failed", message: "The file could not be downloaded." });
          await persist();
          return;
        }
        try {
          const uploaded = await ink.uploadFile({ workspaceId: draft.workspaceId, folderId: draft.folderId, name: file.name, bytes });
          fileBytes.delete(file.url);
          session = reduce(session, { type: "placed", id: "document", upload: { id: uploaded.id, width: null, height: null } });
        } catch (err) {
          session = reduce(session, { type: "failed", message: err instanceof InkError ? err.message : "The file could not be uploaded." });
          await persist();
          return;
        }
        await persist();
      }
      if (session.status !== "saving") return;
      for (const image of blockImages(session.clip)) {
        if (session.status !== "saving") return;
        const id = placeId(image);
        if (!id) {
          const reason = image.source.kind === "skip" ? image.source.reason : "unreadable";
          session = reduce(session, { type: "miss", miss: { key: image.key, reason } });
          continue;
        }
        if (session.placed[id]) continue;
        const bytes = image.source.kind === "inline" ? inlineBytes(image) : image.source.kind === "remote" ? await fetchImage(image.source.url) : null;
        const plan = planImage(bytes);
        if (plan.action === "miss") {
          session = reduce(session, { type: "miss", miss: { key: image.key, reason: plan.reason } });
          await persist();
          continue;
        }
        try {
          const uploaded = await ink.uploadImage({ workspaceId: draft.workspaceId, folderId: draft.folderId, name: plan.name, bytes: plan.bytes });
          const box = imageBox(uploaded, image);
          session = reduce(session, { type: "placed", id, upload: { id: uploaded.id, width: box?.width ?? null, height: box?.height ?? null } });
        } catch (err) {
          const reason = err instanceof InkError && err.code === "not-image" ? "not-image" : "unfetched";
          session = reduce(session, { type: "miss", miss: { key: image.key, reason } });
        }
        await persist();
      }
      if (session.status !== "saving") return;
      const placed = session.placed;
      const text2 = clipToMarkdown(session.clip, draft.title, placed);
      if (text2.length > NOTE_TEXT_LIMIT) {
        session = reduce(session, { type: "failed", message: "This clip is too long for a note." });
        await persist();
        return;
      }
      try {
        const note = await ink.createNote({ workspaceId: draft.workspaceId, folderId: draft.folderId, text: text2, writeId: session.createKey });
        session = reduce(session, { type: "noted", note: { id: note.id, slug: note.slug, title: note.title || draft.title } });
        await persist();
        if (session.status !== "saving" || !session.note) return;
        session = reduce(session, { type: "created", note: { ...session.note, url: noteUrl(auth.host, session.note) } });
        lastPlace = { workspaceId: draft.workspaceId, folderId: draft.folderId };
        await chrome.storage.local.set({ lastPlace });
        await chrome.action.setBadgeText({ text: "" });
        await persist();
      } catch (err) {
        session = reduce(session, { type: "failed", message: err instanceof InkError ? err.message : "Could not save the note." });
        await persist();
      }
    }
    async function takeFile(file) {
      fileBytes.set(file.url, file.bytes);
      const now = /* @__PURE__ */ new Date();
      const clip = {
        mode: "page",
        title: file.title,
        source: { pageTitle: file.name, pageUrl: file.url, clippedOn: `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}` },
        blocks: [],
        file: { name: file.name, url: file.url }
      };
      touched = Date.now();
      session = reduce(session, { type: "captured", clip, defaults: { ...defaultsFor(clip.title), title: clip.title || "Untitled" } });
      notice = null;
      await persist();
      await ensureFolders(session.status === "review" ? session.draft.workspaceId : null, true);
      if (session.status === "review" && !session.draft.folderId && folders.status === "ready") {
        session = reduce(session, { type: "draft", patch: { folderId: defaultFolder(folders.list, lastPlace, folders.workspaceId) } });
        await persist();
      }
      return view();
    }
    async function adopt(token, host) {
      notice = null;
      try {
        const client = createInk({ token: token.trim(), host: host.trim() });
        const list = await client.listWorkspaces();
        auth = { token: token.trim(), host: new URL(host.trim().includes("://") ? host.trim() : `https://${host.trim()}`).origin };
        personName = list.person.name;
        readOnly = list.readOnly;
        workspaces = list.workspaces;
        rejected = false;
        await chrome.storage.local.set({ auth });
        if (session.status === "review" || session.status === "failed") {
          const workspaceId = session.draft.workspaceId ?? defaultWorkspace(workspaces, lastPlace?.workspaceId ?? null);
          session = reduce(session, { type: "draft", patch: { workspaceId, folderId: null } });
          folders = { status: "empty" };
          await ensureFolders(workspaceId, true);
          await persist();
        }
      } catch (err) {
        rejected = true;
        notice = err instanceof InkError ? err.message : "Could not connect.";
      }
      return view();
    }
    const ready = load();
    const api = {
      getState: () => enqueue(async () => {
        await ready;
        const workspaceId = session.status === "review" || session.status === "failed" ? session.draft.workspaceId : null;
        await ensureFolders(workspaceId);
        return view();
      }),
      wake: () => enqueue(async () => {
        await ready;
        const next = settle(session, touched, Date.now());
        if (next.status !== session.status) {
          session = next;
          notice = null;
          await chrome.action.setBadgeText({ text: "" });
          await persist();
        }
        if (folders.status === "ready" || folders.status === "error") folders = { status: "empty" };
        const workspaceId = session.status === "review" || session.status === "failed" ? session.draft.workspaceId : null;
        await ensureFolders(workspaceId, true);
        return view();
      }),
      signIn: (host) => enqueue(async () => {
        await ready;
        notice = null;
        let origin;
        try {
          origin = new URL(host.trim().includes("://") ? host.trim() : `https://${host.trim() || "commonink.app"}`).origin;
        } catch {
          notice = "The host must be an http(s) address.";
          return view();
        }
        const redirect = chrome.identity.getRedirectURL();
        let back;
        try {
          back = await chrome.identity.launchWebAuthFlow({ url: `${origin}/clipper/connect?redirect=${encodeURIComponent(redirect)}`, interactive: true });
        } catch {
          notice = "Sign-in was cancelled.";
          return view();
        }
        let granted = "";
        try {
          granted = new URLSearchParams((back ? new URL(back).hash : "").replace(/^#/, "")).get("token") ?? "";
        } catch {
          granted = "";
        }
        if (!granted.startsWith("cink_")) {
          notice = "Sign-in did not finish.";
          return view();
        }
        return adopt(granted, origin);
      }),
      connect: (token, host) => enqueue(async () => {
        await ready;
        return adopt(token, host);
      }),
      disconnect: () => enqueue(async () => {
        await ready;
        if (auth) await createInk(auth).signOut().catch(() => void 0);
        auth = null;
        personName = null;
        readOnly = false;
        rejected = false;
        workspaces = [];
        folders = { status: "empty" };
        lastPlace = null;
        notice = null;
        await chrome.storage.local.remove(["auth", "lastPlace"]);
        await persist();
        return view();
      }),
      capture: (tabId, frameId, mode) => enqueue(async () => {
        await ready;
        if (session.status === "saving") return view();
        notice = null;
        touched = Date.now();
        const tabUrl = await tabAddress(tabId);
        if (mode === "page" && tabUrl && urlLooksLikeDocument(tabUrl)) {
          const downloaded = await fetchDocument(tabUrl);
          if (downloaded === "too-big") {
            notice = "This file is too big to clip.";
            return view();
          }
          if (downloaded) return takeFile(downloaded);
        }
        const previous = session;
        session = reduce(session, { type: "clipping" });
        await persist();
        let response;
        try {
          response = await within(chrome.tabs.sendMessage(tabId, { type: "capture", mode }, { frameId }), CLIP_MS);
        } catch (err) {
          const downloaded = mode === "page" && tabUrl ? await fetchDocument(tabUrl) : null;
          if (downloaded === "too-big") {
            session = { status: "idle" };
            notice = "This file is too big to clip.";
            await persist();
            return view();
          }
          if (downloaded) return takeFile(downloaded);
          session = previous.status === "clipping" ? { status: "idle" } : previous;
          notice = err instanceof Error && err.message === "timeout" ? "This page took too long to clip." : "This page can't be clipped.";
          await persist();
          return view();
        }
        if (!response || response.type === "capture-failed") {
          const downloaded = mode === "page" && tabUrl ? await fetchDocument(tabUrl) : null;
          if (downloaded && downloaded !== "too-big") return takeFile(downloaded);
          session = previous.status === "clipping" ? { status: "idle" } : previous;
          notice = downloaded === "too-big" ? "This file is too big to clip." : response?.message || "Could not clip this page.";
          await persist();
          return view();
        }
        return take(response.capture);
      }),
      accept: (capture) => enqueue(async () => {
        await ready;
        return take(capture);
      }),
      setDraft: (patch) => enqueue(async () => {
        await ready;
        const previous = session.status === "review" || session.status === "failed" ? session.draft.workspaceId : null;
        session = reduce(session, { type: "draft", patch });
        if ((session.status === "review" || session.status === "failed") && patch.workspaceId && patch.workspaceId !== previous) {
          session = reduce(session, { type: "draft", patch: { folderId: null } });
          folders = { status: "empty" };
          await ensureFolders(patch.workspaceId);
        }
        await persist();
        return view();
      }),
      save: () => enqueue(async () => {
        await ready;
        if (readOnly) {
          notice = "This agent can only read.";
          return view();
        }
        notice = null;
        session = reduce(session, { type: "save" });
        await persist();
        await commit();
        return view();
      }),
      dismiss: () => enqueue(async () => {
        await ready;
        session = reduce(session, { type: "dismiss" });
        notice = null;
        await chrome.action.setBadgeText({ text: "" });
        await persist();
        return view();
      })
    };
    return api;
  }
  function within(promise, ms) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("timeout")), ms);
      promise.then(
        (value) => {
          clearTimeout(timer);
          resolve(value);
        },
        (err) => {
          clearTimeout(timer);
          reject(err);
        }
      );
    });
  }
  async function tabAddress(tabId) {
    try {
      return (await chrome.tabs.get(tabId)).url ?? null;
    } catch {
      return null;
    }
  }
  async function refetchDocument(url) {
    const downloaded = await fetchDocument(url);
    return downloaded && downloaded !== "too-big" ? downloaded.bytes : null;
  }
  async function maybeVideo(clip) {
    const watch = watchTarget(clip.source.pageUrl);
    if (!watch || clip.mode !== "page" || !thinVideo(clip.title, clipText(clip))) return clip;
    const card = await fetchWatch(watch);
    return card ? clipWithVideo(clip, card, watch) : clip;
  }
  async function maybeTweet(clip) {
    const page = tweetTarget(clip.source.pageUrl);
    const linked = firstHref(clip);
    const target = clip.mode === "link" ? linked ? tweetTarget(linked) : null : page && thinTweet(clip) ? page : null;
    if (!target) return clip;
    const html = await fetchOembed(target.permalink);
    if (!html) return clip;
    const tweet = tweetFromOembed(html, target.permalink);
    return tweet ? clipWithTweet(clip, tweet) : clip;
  }
  function thinTweet(clip) {
    const text2 = clipText(clip);
    return text2.length < 40 || /log in|sign up|javascript/i.test(text2);
  }
  function clipText(clip) {
    const parts = [];
    const walk = (inlines) => {
      for (const inline of inlines) {
        if (inline.type === "text") parts.push(inline.text);
        else if (inline.type !== "code") walk(inline.inlines);
      }
    };
    for (const block of clip.blocks) {
      if (block.type === "paragraph" || block.type === "heading") walk(block.inlines);
    }
    return parts.join(" ").replace(/\s+/g, " ").trim();
  }
  function firstHref(clip) {
    for (const block of clip.blocks) {
      if (block.type !== "paragraph") continue;
      for (const inline of block.inlines) if (inline.type === "link") return inline.href;
    }
    return null;
  }
  function isAuth(value) {
    return !!value && typeof value === "object" && typeof value.token === "string" && typeof value.host === "string";
  }
  function isPlace(value) {
    return !!value && typeof value === "object" && typeof value.workspaceId === "string" && typeof value.folderId === "string";
  }
  function isSession(value) {
    return !!value && typeof value === "object" && typeof value.status === "string";
  }

  // extension/src/background.ts
  var CAPTURES = [
    { id: "page", title: "Clip page to Common Ink", contexts: ["page"] },
    { id: "selection", title: "Clip selection to Common Ink", contexts: ["selection"] },
    { id: "link", title: "Clip link to Common Ink", contexts: ["link"] },
    { id: "image", title: "Clip image to Common Ink", contexts: ["image"] },
    { id: "element", title: "Clip element to Common Ink", contexts: ["page", "selection", "link", "image"] }
  ];
  var clipper = createClipper();
  chrome.runtime.onInstalled.addListener(() => {
    void chrome.action.setBadgeBackgroundColor({ color: "#5b5bd6" });
    chrome.contextMenus.removeAll(() => {
      for (const item of CAPTURES) chrome.contextMenus.create({ id: item.id, title: item.title, contexts: item.contexts });
    });
  });
  chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (!tab?.id || typeof info.menuItemId !== "string") return;
    const mode = CAPTURES.find((item) => item.id === info.menuItemId)?.id;
    if (!mode) return;
    void open();
    void clipper.capture(tab.id, mode === "page" ? 0 : info.frameId ?? 0, mode);
  });
  chrome.commands.onCommand.addListener((command) => {
    if (command !== "clip-page") return;
    void open();
    void clipActive("page");
  });
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || typeof message !== "object" || !answers(message.type, sender, chrome.runtime.id)) return;
    const respond = (state) => {
      void state.then(sendResponse).catch((err) => sendResponse({ notice: err instanceof Error ? err.message : "Something went wrong." }));
      return true;
    };
    switch (message.type) {
      case "status":
        return respond(clipper.getState());
      case "wake":
        return respond(clipper.wake());
      case "signIn":
        return respond(clipper.signIn(String(message.host ?? "")));
      case "connect":
        return respond(clipper.connect(String(message.token ?? ""), String(message.host ?? "")));
      case "disconnect":
        return respond(clipper.disconnect());
      case "capture":
        void open();
        return respond(clipActive(message.mode === "selection" ? "selection" : "page", typeof message.tabId === "number" ? message.tabId : void 0));
      case "save":
        return respond(clipper.save());
      case "dismiss":
        return respond(clipper.dismiss());
      case "setDraft":
        return respond(clipper.setDraft(message.patch ?? {}));
      default:
        return;
    }
  });
  async function clipActive(mode, tabId) {
    const id = tabId ?? (await chrome.tabs.query({ active: true, currentWindow: true }))[0]?.id;
    if (!id) {
      const state = await clipper.getState();
      return { ...state, notice: "No page to clip." };
    }
    return clipper.capture(id, 0, mode);
  }
  function open() {
    const popup = chrome.action.openPopup?.();
    if (!popup) return chrome.action.setBadgeText({ text: "1" }).then(() => void 0);
    return popup.catch(() => chrome.action.setBadgeText({ text: "1" }).then(() => void 0));
  }
})();
